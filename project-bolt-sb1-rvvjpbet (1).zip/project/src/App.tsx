import React, { useState } from 'react';
import { GraduationCap, Menu } from 'lucide-react';

function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create email content
    const subject = encodeURIComponent('Регистрация на вебинар по корейскому языку');
    const body = encodeURIComponent(
      `Новая регистрация на вебинар:\n\n` +
      `Имя: ${formData.name}\n` +
      `Email: ${formData.email}\n` +
      `Телефон: ${formData.phone}\n\n` +
      `Дата вебинара: 22 февраля 2025, 18:00 МСК`
    );

    // Open default email client
    window.location.href = `mailto:muzykalymektep@mail.ru?subject=${subject}&body=${body}`;
    
    // Reset form
    setFormData({ name: '', email: '', phone: '' });
  };

  return (
    <div className="min-h-screen bg-[#5B21B6] relative overflow-hidden">
      {/* 3D Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Large floating sphere */}
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full opacity-30 animate-float" 
             style={{ 
               transform: 'perspective(1000px) rotateX(45deg) rotateY(-45deg)',
               animation: 'float 20s ease-in-out infinite'
             }} />
        
        {/* Floating cubes */}
        <div className="absolute top-1/4 left-20 w-32 h-32 bg-yellow-300/20 rounded-lg"
             style={{ 
               transform: 'perspective(1000px) rotateX(45deg) rotateY(45deg)',
               animation: 'float 15s ease-in-out infinite'
             }} />
        
        <div className="absolute bottom-1/4 right-40 w-24 h-24 bg-purple-400/20 rounded-lg"
             style={{ 
               transform: 'perspective(1000px) rotateX(-35deg) rotateY(45deg)',
               animation: 'floatReverse 18s ease-in-out infinite'
             }} />
        
        {/* Abstract shapes */}
        <div className="absolute top-1/2 left-1/4 w-40 h-40 bg-gradient-to-tr from-yellow-200/20 to-purple-500/20"
             style={{ 
               clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
               transform: 'perspective(1000px) rotateX(60deg) rotateY(0deg)',
               animation: 'spin 25s linear infinite'
             }} />
      </div>

      {/* Navigation */}
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 relative">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <GraduationCap className="h-8 w-8 text-white" />
            <span className="text-white font-bold text-xl">K-R</span>
          </div>
          <div className="hidden md:flex space-x-8">
            {['Главная', 'О нас', 'Программа', 'Блог', 'Контакты'].map((item) => (
              <a key={item} href="#" className="text-white/80 hover:text-white transition-colors">
                {item}
              </a>
            ))}
          </div>
          <button className="md:hidden text-white">
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute -left-8 -top-8 w-16 h-16 bg-yellow-300/30 rounded-lg"
                 style={{ 
                   transform: 'perspective(1000px) rotateX(45deg) rotateY(45deg)',
                   animation: 'float 12s ease-in-out infinite'
                 }} />
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Изучайте
              <br />
              <span className="text-yellow-300">корейский язык</span>
              <br />
              онлайн
            </h1>
            <p className="text-white/80 text-lg mb-8 max-w-lg">
              Присоединяйтесь к нашему бесплатному вебинару и откройте для себя увлекательный мир корейского языка и культуры
            </p>
            <button
              onClick={() => document.getElementById('register')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-yellow-300 text-purple-900 px-8 py-4 rounded-lg font-bold text-lg hover:bg-yellow-400 transition-colors relative overflow-hidden group"
            >
              <span className="relative z-10">Начать обучение</span>
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-200 to-yellow-400 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
            </button>
          </div>
          <div className="relative">
            <div className="w-full h-[400px] bg-[url('https://images.unsplash.com/photo-1584037013266-f16ea3eec9df?auto=format&fit=crop&q=80')] bg-cover bg-center rounded-2xl transform rotate-6 hover:rotate-0 transition-transform duration-500 relative" 
                 style={{ transformStyle: 'preserve-3d' }}>
              <div className="absolute inset-0 bg-purple-900/30 rounded-2xl backdrop-blur-sm"></div>
              <div className="absolute -right-8 -bottom-8 w-20 h-20 bg-purple-500/30 rounded-lg"
                   style={{ 
                     transform: 'perspective(1000px) rotateX(-35deg) rotateY(45deg)',
                     animation: 'floatReverse 14s ease-in-out infinite'
                   }} />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-yellow-300 p-6 rounded-xl transform rotate-12 hover:rotate-0 transition-transform duration-500">
              <p className="text-purple-900 font-bold">22 февраля 2025</p>
              <p className="text-purple-900/80">18:00 МСК</p>
            </div>
          </div>
        </div>
      </div>

      {/* Registration Form */}
      <div id="register" className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
        <div className="bg-white rounded-2xl p-8 shadow-xl transform hover:-translate-y-1 transition-transform duration-300">
          <h2 className="text-3xl font-bold text-purple-900 mb-8 text-center">Регистрация на вебинар</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Ваше имя
              </label>
              <input
                type="text"
                id="name"
                required
                className="w-full px-4 py-3 border-2 border-purple-100 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                required
                className="w-full px-4 py-3 border-2 border-purple-100 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Телефон
              </label>
              <input
                type="tel"
                id="phone"
                required
                className="w-full px-4 py-3 border-2 border-purple-100 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-4 px-6 rounded-lg font-bold text-lg hover:bg-purple-700 transition-colors"
            >
              Зарегистрироваться
            </button>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: perspective(1000px) rotateX(45deg) rotateY(-45deg) translateY(0px); }
          50% { transform: perspective(1000px) rotateX(45deg) rotateY(-45deg) translateY(-20px); }
        }
        
        @keyframes floatReverse {
          0%, 100% { transform: perspective(1000px) rotateX(-35deg) rotateY(45deg) translateY(-20px); }
          50% { transform: perspective(1000px) rotateX(-35deg) rotateY(45deg) translateY(0px); }
        }
        
        @keyframes spin {
          from { transform: perspective(1000px) rotateX(60deg) rotateY(0deg); }
          to { transform: perspective(1000px) rotateX(60deg) rotateY(360deg); }
        }
      `}</style>
    </div>
  );
}

export default App;